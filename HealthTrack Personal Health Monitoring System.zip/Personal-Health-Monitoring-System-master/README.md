# Personal-Health-Monitoring-System
The project aims to provide an android app service for users to track, maintain and edit their health records. This includes setting reminders, adding diet information, tracking vital signs and other health related information.

API Copyright: https://betterdoctor.com/
